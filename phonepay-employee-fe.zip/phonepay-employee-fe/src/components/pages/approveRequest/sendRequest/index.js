import { Button, FormHelperText, TextField } from '@mui/material';
import { useState } from 'react';
import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';
import { DesktopDatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { toast } from 'react-toastify';
import { RiErrorWarningFill } from 'react-icons/ri';
import { BsFillCheckCircleFill } from 'react-icons/bs';
import APIList from '../../../../api';
import { useSelector } from 'react-redux';
import Avatar from 'react-avatar';
import { isEmptyNullUndefined } from '../../../utils/utils';
import PropTypes from 'prop-types';

const SendReq = ({requestFrom, feedbackFor, peer, setIsOpen, setSearch, getPageData, getSentCount, cancelInitiate, getCount}) => {  
  console.log('requestFrom ===', requestFrom)
  console.log('feedbackFor ===', feedbackFor)

    const employeeDetails = useSelector((state) => state?.empData?.empData);
    const pmsCycleData = useSelector((state) => state.pmscycleReducer.pmscycle[0]);

    const [dateExpected, setDateExpected] = useState(null);
    const [submitLoader, setSubmitLoader] = useState(false);
    const [msgErr, setMsgErr] = useState(false);
    const [dateErr, setDateErr] = useState(false);


    let defaultMsg = `<p>
  <p>Dear ${feedbackFor?.employeeName},</p>

  <p> I hope this message finds you well.</p>

  <p> As part of my performance appraisal process, I would greatly appreciate your valuable feedback.
   Your insights are crucial to my professional growth. Please take a moment to share your thoughts. Thank you for your time. </p>

   Best regards,
   <p>${employeeDetails?.name}</p>
  </p>`;

  const [message, setMessage] = useState(defaultMsg);

    const handleChange = (value) => {
        setMessage(value);
        setMsgErr(false);
    }

  const submitRequest = () => { 
      
    if(getIsValid()){
      setSubmitLoader(true);
      APIList.sendFeedbackRequest({

        requestedBy:{ 
          id: requestFrom?.employeeName ? requestFrom?.employeeId : requestFrom.id
          // id: requestFrom?.employeeId
        },
        requestedTo:{
            id: feedbackFor?.employeeId
        },
        relationship: "Peer",
        message: message,
        expiryDate: dateExpected,

        managerInitiatesPeerFeedback: true,
        // initiateManager: { id: 1 },
        // initiateManager: { id: '0e4fe8f3-642e-470f-8f65-44d8dc662d2f' },
        initiateManager: { id: employeeDetails.id},

        isResend: false

        // old
          // requestedBy:{ 
          //     id: employeeDetails?.id
          // },
          // requestedTo:{
          //     id: peer?.employeeId
          // },
          // relationship: "Peer",
          // message: message,
          // expiryDate: dateExpected
      })  
      .then((res) => {
          toast.success(
              <div className="flex flex-row">
                <BsFillCheckCircleFill
                  style={{ width: "2rem", height: "2rem" }}
                />
                {` Request sent successfully`}
              </div>
            );
            setSubmitLoader(false);
            setIsOpen(false);
            setSearch("");
            getPageData();
            // getCount()
            cancelInitiate();
      })
      .catch((err) => {
          toast.error(
              <div style={{display:"flex", flexDirection:"row"}}>
                <RiErrorWarningFill style={{ width: '2rem', height: '2rem' }} />
                &nbsp;&nbsp;{err?.message}
              </div>
          );
          setSubmitLoader(false);
          setSearch("");
      })
    }                
  }

    const getIsValid = () => {
      let isValid = true;

      if(isEmptyNullUndefined(message)){
        setMsgErr(true);
        isValid = false;
      }
      if(isEmptyNullUndefined(dateExpected)){
        setDateErr(true);
        isValid = false;
      }

      return isValid;
    }
    
    return(
        <div className="send-feedback-req-drawer-main">
          <div className="empDetaila">
              <div className="empPic">
              {feedbackFor?.profilePhotoPath ? 
                  <img src={feedbackFor?.profilePhotoPath} className="userImg" alt="User" />
                  :
                  <Avatar 
                      name={feedbackFor?.employeeName} 
                      size="45" 
                      className="userImg"
                      color={"#00425A"}    
                  />
              }
              </div>
              <div className="userInfo">
                  <p className="name">{feedbackFor?.employeeName}</p>
                  {/* <p className="designation">{feedbackFor?.employeeDesignation ? feedbackFor?.employeeDesignation : "Designation"}</p> */}
                  <p className="designation">{feedbackFor?.employeeDesignation ? feedbackFor?.employeeDesignation : ""}</p>
              </div>
          </div>
            <SunEditor
            //  defaultValue={`<p>
            //  <p>Dear ${peer?.employeeName},</p>

            //  <p> I hope this message finds you well.</p>

            //  <p> As part of my performance appraisal process, I would greatly appreciate your valuable feedback.
            //   Your insights are crucial to my professional growth. Please take a moment to share your thoughts. Thank you for your time. </p>

            //   Best regards,
            //   <p>${employeeDetails?.name}</p>
            //  </p>`}
             defaultValue={message}
             autoFocus={true}
             height="20rem"
             setDefaultStyle="font-family: poppins; font-size: 14px;" 
             onChange={handleChange}
             />
                {msgErr && (
                  <FormHelperText sx={{ color: "#d32f2f" }}>
                    Please write message
                  </FormHelperText>
                )}
             <div className='date-outer'>
             <div>Feedback Expected By : </div>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DesktopDatePicker
                  inputFormat={
                    // employeeDetails &&
                    // employeeDetails.empData &&
                    // employeeDetails.empData.company &&
                    // employeeDetails.empData.company.dateFormat &&
                    // employeeDetails.empData.company.dateFormat ||
                    "dd/MM/yyyy"
                  }
                  value={dateExpected}
                  // label="Date of Birth"
                  label="select date"
                  name="feedbackExpectedBy"
                  minDate={new Date()}
                  // minDate={pmsCycleData?.[0]?.peerAppraisalStartDate ?? null}
                  maxDate={pmsCycleData?.peerAppraisalEndDate ?? null}
                  onChange={(event) =>
                    // handleChangeDependent(event, "feedbackExpectedBy")
                    {setDateExpected(event);setIsOpen(true);setDateErr(false)}
                  }
                  renderInput={(params) => (
                    <TextField
                      variant="outlined"
                      helperText={dateErr && "Please select date"}
                    //   size="small"
                      sx={{
                        pointerEvents: 'none',
                        '& .MuiOutlinedInput-root': {
                          'button': {
                            pointerEvents: 'all',
                          }},
                        my: 2,
                        width: "63%",
                        //backgroundColor: "#dedede",
                        "& fieldset": {
                          border: "1px solid #dedede",
                        },
                        // "& .MuiInputBase-input:focus": {
                        //   border: "2px solid #fcd25e", // focus
                        // },
                        "& .css-k4qjio-MuiFormHelperText-root": {
                          backgroundColor: "#ffffff",
                          margin: "0px",
                          paddingLeft: "0.5rem",
                        },
                        "& .MuiIconButton-root": {
                        //   paddingLeft: "5rem",
                          borderRadius:"0px"
                        },
                        // ...requiredStyled
                      }}
                      {...params}
                      error={dateErr}
                    />
                  )}
                />                     
              </LocalizationProvider>
              </div>
            <div className="send-btn-div">
             <Button 
                variant="contained"
                sx={{
                    color:"var(--secondary)",
                    backgroundColor:"var(--primary)",
                    borderColor:"var(--primary)",
                    "&:hover":{
                        backgroundColor:"#035c7c",
                        borderColor:"#035c7c",
                    },
                    // marginBottom:"1.5rem",
                    width:"7rem",
                }}
                disabled={
                  submitLoader
                }
                onClick={submitRequest}
                >
                    Send                                     
                </Button>
                </div>
        </div>
    )
}

SendReq.propTypes = {
  requestFrom: PropTypes.object,
  feedbackFor: PropTypes.object,
  peer: PropTypes.object,
  setIsOpen: PropTypes.func,
  setSearch: PropTypes.func,
  getPageData: PropTypes.func,
  getSentCount: PropTypes.func,
  cancelInitiate: PropTypes.func,
  getCount: PropTypes.func,
};

export default SendReq;