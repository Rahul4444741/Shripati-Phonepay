import Avatar from "react-avatar";
import { getFormattedDate, getFormattedTime, isEmptyNullUndefined } from "../../../utils/utils";
import { useEffect, useState } from "react";
import SearchBar from "./searchBar";
import { useSelector } from "react-redux";
import APIList from "../../../../api";
import { toast } from "react-toastify";
import { RiErrorWarningFill } from "react-icons/ri";
import TableSkel from "../../../common/tableSkeleton";
import SideDrawer from "../../../common/sideDrawer";
import { IoCloseSharp } from "react-icons/io5";
import SendReq from "../sendRequest";
import PropTypes from 'prop-types';

// search={search} activeTab={activeTab} = Suggest
const InitiatePage = ({selectedPeer, getCount, search, activeTab, setSearch, isManagerSuggest}) => {
    console.log('selectedPeer initate--', selectedPeer)
    const annualcycleData = useSelector((state) => state?.annualcycleReducer?.annualcycle[0]);
    const employeeDetails = useSelector((state) => state?.empData?.empData);
    
    const dateFormat = useSelector((state) => state?.empData?.empData?.company?.dateFormat);

    const [isInitiate, setIsInitiate] = useState(false);
    const [requestFrom, setRequestFrom] = useState(null);
    const [feedbackFor, setFeedbackFor] = useState(null);
    const [empListLoader, setEmpListLoader] = useState(false);
    const [empList, setEmpList] = useState(null);
    const [sortEmpList, setSortEmpList] = useState(null);

    const [isOpenDrawer, setIsOpenDrawer] = useState(false);

    console.log("selectedPeer",selectedPeer);

    useEffect(() => {
        getPageData();         
    }, []);

    useEffect(() => {
        setSortEmpList(empList);
        getCount() 
    }, [empList])

    useEffect(() => {
        if(!isEmptyNullUndefined(selectedPeer?.requestItem?.requestedBy)){
            setIsInitiate(true);
            console.log('employeeName:selectedPeer?.requestItem?.requestedBy', selectedPeer?.requestItem?.requestedBy)
            setRequestFrom(selectedPeer?.requestItem?.requestedBy);
        }
    }, [])

    const cancelInitiate = () => {
        setRequestFrom(null);
        setFeedbackFor(null);
        setIsInitiate(false);
    }

    const getPageData = (filters, key, pagenumber) => {
        setEmpListLoader(true);
        // /api/work/flow/definition/employee/{employeeId}  GET
        // APIList.workFlowDefinitionEmployee(
            APIList.feedbackRequestInitiateManager(
        //     {
        //     payload : {
        //         employeeEligibilityDTO : filterPayload,
        //         keyword : search,
        //         employeeId : employeeDetails?.id,
        //         status: activeTab,
        //     },
        //     page: currentPage,
        //     size: 10,
        // }
        employeeDetails.id
        // "9feca4ba-b173-4b17-81a7-b44df8023393"
        // "50a01788-f372-48de-afc9-a4ffb5710a70"
        )        
        .then((res) => {
            setEmpList(res?.data);
            setEmpListLoader(false);
        })
        .catch((err) => {
            toast.error(
                <div style={{display:"flex", flexDirection:"row"}}>
                <RiErrorWarningFill style={{ width: '2rem', height: '2rem' }} />
                &nbsp;&nbsp;{err?.title}
                </div>
            );
            setEmpListLoader(false);
        })
    }

    const handleSendRequest = (emp) => {
        setSearch("");
        setIsOpenDrawer(true);
    };

    const handleClearFeedbackFor = () => {
        setFeedbackFor(null);
    }

    return (
        <div className="initiate-page">
            <div className="tablee suggest">
                <table className="feedback-emp-list-table">

                    <tr className="table-head-emp-list">
                        <th>Request from
                            {/* &nbsp;<BiSort onClick={() => handleSort("employeeName")} style={{cursor:"pointer"}} /> */}
                        </th>
                        <th className="mid-cols">
                            Request to
                            {/* &nbsp;<BiSort onClick={() => handleSort("appraisalStatus")} style={{cursor:"pointer"}} /> */}
                        </th>
                        <th className="mid-cols">Request on</th>
                        {/* <th className="mid-cols">Initiate by</th> */}
                        <th className="last-col head">Status</th>
                        {/* <th></th>  */}
                    </tr>

                    {
                        //  searchLoader || empListLoader ? 

                        empListLoader ?
                         <TableSkel />
                         :
                        // [dummyApproveData[0]]?.map((emp, index) => {
                            sortEmpList?.map((emp, index) => {
                            return (
                                // activeTab === "Pending" ?
                                <tr key={emp?.requestedBy?.name}>
                                    <td>
                                        <div className="empDetaila">
                                            <div className="empPic">
                                                {emp?.requestedBy?.profilePhoto ?
                                                    <img src={emp?.requestedBy?.profilePhoto?.path} className="userImg" alt="User" />
                                                    :
                                                    <Avatar
                                                        name={emp?.requestedBy?.name}
                                                        size="45"
                                                        className="userImg"
                                                        color={"#00425A"}
                                                    />
                                                }
                                            </div>
                                            <div className="userInfo">
                                                <p className="name">{emp?.requestedBy?.name}</p>
                                                {/* <p className="designation">{emp?.requestedBy?.employeeDesignation ? emp?.requestedBy?.employeeDesignation : "Designation"}</p> */}
                                                <p className="designation">{emp?.requestedBy?.employeeDesignation ? emp?.requestedBy?.employeeDesignation : ""}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div className="btns">
                                            <p className="name">{emp?.requestedTo?.name}</p>
                                        </div>
                                    </td>
                                    <td>
                                        <div className="btns">
                                            <div>{getFormattedDate(emp?.expiryDate, dateFormat)}</div>
                                            {/* <div>{getFormattedDate(emp?.requestDate, "hh:mm")}</div> */}
                                            <div>{getFormattedTime(emp?.expiryDate, "hh:mm A")}</div>
                                        </div>
                                    </td>
                                    {/* <td>
                                        <div className="btns">
                                            <div>Manager</div>
                                            <div>ID : 12345</div>
                                        </div>
                                    </td> */}

                                    <td className="last-col">
                                        <div className="btns">
                                            Sent
                                        </div>
                                    </td>

                                </tr>



                            )
                        }

                            // }
                        )
                    }

                </table>

                {
                    isInitiate ? 
                    <div className="add-new-initiate-request">
                        <div className="feedback-from">
                            {
                                !isEmptyNullUndefined(requestFrom) ? 
                                <div className="empDetailass">
                                    {console.log('requestFrom===----', requestFrom)}
                                    <div className="empPic">
                                        {requestFrom?.profilePhotoPath ?
                                            <img src={requestFrom?.profilePhotoPath} className="userImg" alt="User" />
                                            :
                                            
                                            <Avatar
                                                name={requestFrom?.employeeName ?? requestFrom?.name}
                                                size="45"
                                                className="userImg"
                                                color={"#00425A"}
                                            />
                                        }
                                    </div>
                                    <div className="userInfo">
                                        <p className="name">{requestFrom.employeeName ?? requestFrom?.name}</p>
                                        {/* <p className="designation">{requestFrom?.employeeDesignation ? requestFrom?.employeeDesignation : "Designation"}</p> */}
                                        <p className="designation">{requestFrom?.employeeDesignation ? requestFrom?.employeeDesignation : ""}</p>
                                    </div>
                                </div>
                                :
                                <SearchBar
                                 placeHoldText="Request feedback from"
                                 setSelected={setRequestFrom}
                                  />

                            }
                        </div>
                        <div className="feedback-for">
                        {
                                !isEmptyNullUndefined(feedbackFor) ? 
                                <div className="empDetailass">
                                    <div className="empPic">
                                        {feedbackFor?.profilePhotoPath ?
                                            <img src={feedbackFor?.profilePhotoPath} className="userImg" alt="User" />
                                            :
                                            <Avatar
                                                name={feedbackFor?.employeeName}
                                                size="45"
                                                className="userImg"
                                                color={"#00425A"}
                                            />
                                        }
                                    </div>
                                    <div className="userInfo">
                                        <p className="name">{feedbackFor?.employeeName}<IoCloseSharp onClick={() => handleClearFeedbackFor()} style={{
                                            marginLeft: '1rem',
                                            cursor: 'pointer',
                                        }} /></p>
                                        {/* <p className="designation">{feedbackFor?.employeeDesignation ? feedbackFor?.employeeDesignation : "Designation"}</p> */}
                                        <p className="designation">{feedbackFor?.employeeDesignation ? feedbackFor?.employeeDesignation : ""}</p>
                                    </div>
                                </div>
                                :
                                <SearchBar
                                 placeHoldText="Request feedback for"
                                 setSelected={setFeedbackFor}
                                  />

                            }
                        </div>
                        <div className="btns">
                            <button className="cancel" onClick={cancelInitiate}>Cancel</button>
                            <button 
                                style={{
                                    opacity: ((!requestFrom || !feedbackFor) ? '60%' : '100%'),
                                    pointerEvents: ((!requestFrom || !feedbackFor) ? 'none' : 'auto'),
                                }}
                                className="send" 
                                onClick={() => handleSendRequest()}
                            >Send</button>
                        </div>
                    </div>
                    :
                    (
                        
                        (((annualcycleData?.pmsCycle?.peerReviewInitiator == "Manager") || (annualcycleData?.pmsCycle?.peerReviewInitiator == "Both")) || isManagerSuggest) &&
                        (<button className="add-new-initiate" onClick={() => setIsInitiate(true)}>
                          + Add New Initiate
                        </button>)

                    )
                }

        {
            // isOpenDrawer && isSendRequest && !isEmptyNullUndefined(selectedPeer) &&
            isOpenDrawer &&
            <SideDrawer isOpen={isOpenDrawer} setIsOpen={setIsOpenDrawer} >
               { console.log('requestFrom ====', requestFrom)}
               { console.log('feedbackFor ====', feedbackFor)}
                {/* <SendReq peer={selectedPeer} setIsOpen={setIsOpenDrawer} setSearch={setSearch} getPageData={getPageData} getSentCount={0} /> */}
                <SendReq getCount={() => getCount()} requestFrom={requestFrom} feedbackFor={feedbackFor} peer={selectedPeer} setIsOpen={setIsOpenDrawer} setSearch={setSearch} getPageData={getPageData} cancelInitiate={() => cancelInitiate()} getSentCount={0} />
            </SideDrawer>
         } 
                
            </div>
        </div>
    )
}

InitiatePage.propTypes = {
    selectedPeer: PropTypes.object,
    getCount: PropTypes.func,
    search: PropTypes.string,
    activeTab: PropTypes.string,
    setSearch: PropTypes.func,
    isManagerSuggest: PropTypes.bool,
  };

export default InitiatePage;