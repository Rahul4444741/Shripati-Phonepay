import { IoClose } from "react-icons/io5";
import { Avatar, Menu, MenuItem } from "@mui/material";
import React, { useEffect, useState, useRef } from "react";
import APIList from "../../../api";
import { RiErrorWarningFill } from "react-icons/ri";
import { IoArrowDownOutline, IoFilter } from "react-icons/io5";
import {
  getObjById,
  isEmptyNullUndefined,
  removeEmptyArrays,
  returnNameByKey,
} from "../../utils/utils";
import { useSelector, useDispatch } from "react-redux";
import { toast } from "react-toastify";
import ThreeSixtyHeaderIcon from "../../../assets/images/dynamicSidebar/threeSixtyHeaderIcon";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import Filters from "../teamview/Filters";

const initialFilters = {
  // employeeGrade: [],
}

const ApproveNominations = () => {
  const employeeDetails = useSelector((state) => state?.empData?.empData);
  const dispatch = useDispatch();
  const [myTeamData, setMyTeamData] = useState();

  useEffect(() => {
    if (employeeDetails?.id) {
      getMyTeamData();
    }
  }, [employeeDetails]);
  const dropdownRef = useRef(null);
  // const { promisedata, profiledata } = useEmployee();
  const history = useHistory();
  const clickEmp = (empId, compId) => {
    history?.push(`/employee-profile/${empId}`);
  };

  const [page, setPage] = useState(1);
  console.log("employeeDetails", employeeDetails);

  const [myTeamDataSearch, setMyTeamDataSearch] = useState([]);
  const [myTeamLoader, setMyTeamLoader] = useState(false);
  const [searchvalue, setSearchValue] = useState("");

  const [activeTab, setActiveTab] = useState(null);

  const [isSettingDropDownOpen, setIsSettingDropDownOpen] = useState(false);

  const [selectedOptions, setSelectedOptions] = useState(
    JSON.parse(JSON.stringify(initialFilters))
  );

  const [filterData, setFilterData] = useState(
    JSON.parse(JSON.stringify(initialFilters))
  );

  const [searchLoading, setSearchLoading] = useState(false);

  const [isSubEmployeeLoading, setIsSubEmployeeLoading] = useState(false);
  const [subEmployeeLoadId, setSubEmployeeLoad] = useState(null);

  const handleCloseFilter = () => {
    setIsSettingDropDownOpen(() => false);
  };

  const getMyTeamData = (filteredData, isFiltered) => {
    setMyTeamLoader(true);
    APIList.getApproveNomination({
      payload: {
        employeeEligibilityDTO: isFiltered == true ? filteredData : {}, //{},
        filterData: isFiltered == true ? true : false, //false,
        keyword: "",
        managerId: employeeDetails?.id,
        companyId: employeeDetails?.company?.id,
        // "managerId": "4b6fa605-ba6c-41ed-8d35-6159cf78c6de",
        // "companyId": "ba02f418-e44d-467c-9d5d-421a2d966460",
        page: "My Team",
        hrbp: activeTab === "Hrbp" ? true : false,
      },
      page: page - 1,
      size: 10,
    })
      .then((res) => {
        setMyTeamData(res?.data);

        setMyTeamLoader(false);
      })
      .catch((err) => {
        toast.error(
          <div style={{ display: "flex", flexDirection: "row" }}>
            <RiErrorWarningFill style={{ width: "2rem", height: "2rem" }} />
            &nbsp;&nbsp;{err?.title}
          </div>
        );
        setMyTeamLoader(false);
      });
  };

  const handleResetFilter = () => {
    setSelectedOptions(() => initialFilters);
    if (page == 1) {
      getMyTeamData();
    } else {
      setPage(() => 1); // this will auto call getMyTeamData throw useEffect
    }
  };


  const settingHandler = () => {
    if (!isSettingDropDownOpen) {
      setIsSettingDropDownOpen(true);
    }
  };

  const [open, setOpen] = React.useState({});
  const checkIsThereAnyFilter = (selectedOptions) => {
    let tempselectedOptions = JSON.parse(JSON.stringify(selectedOptions));
    ///// check is filter empty
    let onlyDataSelectedOptions = removeEmptyArrays(
      JSON.parse(JSON.stringify(tempselectedOptions))
    );
    let selectedOptionsArray = Object.keys(onlyDataSelectedOptions);
    ////

    if (selectedOptionsArray.length == 0) {
      return false;
    } else {
      return true;
    }
  };

  const handleFilteredData = (selectedOptions) => {
    checkIsThereAnyFilter(selectedOptions)
      ? getMyTeamData(selectedOptions, true)
      : getMyTeamData(); // true for isFiltered
    handleCloseFilter();

    setSelectedOptions(() => selectedOptions);
    console.log("selectedOptions", selectedOptions);

    //
    let tempSelectedOptions = JSON.parse(JSON.stringify(selectedOptions));
    let onlyDataSelectedOptions = removeEmptyArrays(tempSelectedOptions);
    let selectedOptionsArray = Object.keys(onlyDataSelectedOptions);
    // setting initialOpen
    let tempOpen = {};
    selectedOptionsArray?.forEach((e, i) => {
      tempOpen[e] = null;
    });
    setOpen(() => tempOpen);
  };

  const handleDeleteFilterCart = (
    selectedOption,
    index,
    tempselectedOptions
  ) => {
    tempselectedOptions[selectedOption].length = 0;
    ///// check is filter empty
    let onlyDataSelectedOptions = removeEmptyArrays(
      JSON.parse(JSON.stringify(tempselectedOptions))
    );
    let selectedOptionsArray = Object.keys(onlyDataSelectedOptions);
    ////

    setSelectedOptions(() => tempselectedOptions);

    if (selectedOptionsArray.length == 0) {
      if (page == 1) {
        getMyTeamData();
      } else {
        setPage(() => 1);
      }
    } else {
      if (page == 1) {
        getMyTeamData(tempselectedOptions, true);
      } else {
        setPage(() => 1);
      }
    }
  };

  const handleUpdatefilterDataList = (filterDataList) => {
    setFilterData(() => filterDataList);
  };
  const [anchorEl, setAnchorEl] = React.useState(null);
  const handleClick = (event, name) => {
    console.log("handleClick name", name);
    let tempopen = JSON.parse(JSON.stringify(open));
    console.log("handleClick tempopen", tempopen);
    tempopen[name] = true;
    // console.log('event.currentTarget', event.currentTarget)
    setAnchorEl(event.currentTarget);
    setOpen(() => tempopen);
  };
  const handleClose = (name) => {
    setAnchorEl(null);
    console.log("handle close name", name);

    let tempopen = JSON.parse(JSON.stringify(open));
    // console.log('handleClick tempopen',tempopen)
    tempopen[name] = false;

    console.log("tempopen----", tempopen);
    setOpen(() => tempopen);
  };

  const renderFilterCards = () => {
    let tempfilterData = JSON.parse(JSON.stringify(filterData));
    let tempSelectedOptions = JSON.parse(JSON.stringify(selectedOptions));
    let onlyDataSelectedOptions = removeEmptyArrays(tempSelectedOptions);
    let selectedOptionsArray = Object.keys(onlyDataSelectedOptions);

    return selectedOptionsArray.map((selectedOption, index) => {
      console.log("tempfilterData--", tempfilterData);
      console.log("selectedOption--", selectedOption);
      return (
        <>
          <div
            key={index}
            className="d-flex filter-card"
            id="basic-button"
            aria-controls={open[selectedOption] ? "basic-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open[selectedOption] ? "true" : undefined}
            onClick={(event) => handleClick(event, selectedOption)}
          >
            <div className="title">
              {returnNameByKey(selectedOption)}:
              {console.log(tempSelectedOptions[selectedOption][0])}
              {
                getObjById(
                  tempSelectedOptions[selectedOption][0],
                  tempfilterData[selectedOption]
                ).name
              }
            </div>
            {tempSelectedOptions[selectedOption].length > 1 ? (
              <div className="filter-count">
                {`+${tempSelectedOptions[selectedOption].length - 1}`}
              </div>
            ) : null}
            <div
              onClick={() =>
                handleDeleteFilterCart(
                  selectedOption,
                  index,
                  JSON.parse(JSON.stringify(selectedOptions))
                )
              }
              className="delete"
            >
              <IoClose />
            </div>
          </div>
          <Menu
            sx={{
              "& .MuiPopover-paper": {
                borderRadius: "8px",
              },
              "& .MuiMenuItem-root": {
                fontFamily: "Inter",
                fontSize: "14px",
                fontWeight: "500",
                lineHeight: "20px",
                textAlign: "left",
                pointerEvents: "none",
              },
            }}
            id="basic-menu"
            anchorEl={anchorEl}
            open={open[selectedOption]}
            onClose={() => handleClose(selectedOption)}
            MenuListProps={{
              "aria-labelledby": "basic-button",
            }}
          >
            {tempSelectedOptions[selectedOption].map((item, index) => (
              <MenuItem
                key={index}
                onClick={() => handleClose(selectedOption)}
              >
                {getObjById(item, tempfilterData[selectedOption]).name}
              </MenuItem>
            ))}
          </Menu>
        </>
      );
    });
  };

  const handleSetInitialSelectedOptions = (initialSelectedOption) => {
    setSelectedOptions(() => initialSelectedOption);
  };
 
  return (
    <div className="ask-for-feedback-page">
      <p className="header-title">360 Feedback</p>

      <div className="main-card">
        <div
          className="text"
          style={{
            alignContent: "center",
          }}
        >
          <div
            className="header"
            style={{
              fontWeight: "600",
              fontSize: "24px",
              color: "white",
              marginBottom: "8px",
            }}
          >
            Welcome to Mid Year 2023-24: 360 Feedback Process
          </div>
          <div className="paragraph">
            <div
              style={{
                fontWeight: "400",
                fontSize: "14",
                color: "#D6BBFB",
              }}
            >
              1. Nomination - Click on Ask for feedback to nominate stakeholders
              for 360 feedback. Once you’re done nominating stakeholders, click
              on send approval request.
            </div>
            <div
              style={{
                fontWeight: "400",
                fontSize: "14",
                color: "#D6BBFB",
              }}
            >
              2. Evaluation - Under Give feedback to others, click on the
              relevant employee name to fill their 360 feedback form.
            </div>
          </div>
        </div>
        <div className="icon">
          <ThreeSixtyHeaderIcon />
        </div>
      </div>
      <div className="my-3">
        <h4>Finalize</h4>
        <p style={{ color: "grey" }}>
          Add approve feedback request for your team
        </p>
      </div>
      <div className="  d-flex gap-2 align-items-center justify-content-between my-3">
        <div className="  d-flex gap-2 ">
          <p className=" p-0" style={{ color: "grey" }}>
            Approval pending <b style={{ color: "#000" }}>5 /10</b>
          </p>
          <p className=" p-0" style={{ color: "grey" }}>
            Direct report with ZERO nominations :{" "}
            <b style={{ color: "#000" }}>3 /10</b>
          </p>
        </div>

        <div className="add-respondent m-0 flex    gap-2">
          <button className="button">
            <IoArrowDownOutline /> Nomination Status
          </button>

          <button className="button">
            <IoArrowDownOutline /> Feedback Raw data
          </button>
        </div>
      </div>
      <div className="emp-profile-main p-0">
        <div className="breadcumb">
          {/* showint route (team view >) */}

          {/* <p className="subPage">Member</p> */}
        </div>
        <div className="profile">
          <div className="searchBar">
            <div className="d-flex w-100 justify-content-between align-items-center">
              <div className="d-flex g-3 align-items-center">
                <p className="search-title">
                  {/* Search for Team Members */}
                  List of direct report
                </p>

                <div className="nav-tabs-outer"></div>
              </div>

              <div className="right-container-search">
                <div
                  className="search-filters d-flex align-items-baseline"
                  onClick={() => settingHandler()}
                  style={{
                    pointerEvents: isSettingDropDownOpen ? "none" : "auto",
                  }}
                >
                  <div className="filters-icon">
                    <IoFilter />
                  </div>
                  <div className="filters-title">Filters</div>
                  <div className="filters-count">
                    {(() => {
                      let count = 0;
                      for (let key in selectedOptions) {
                        // if (obj.hasOwnProperty(key)) {
                        //     console.log(key, obj[key]);
                        // }
                        console.log("key", key);
                        count = count + selectedOptions[key].length;
                      }
                      if (!isEmptyNullUndefined(count) && !(count == 0)) {
                        return `+${count}`;
                      }
                      // return count
                    })()}
                    {/* 20 */}
                  </div>
                </div>
                {isSettingDropDownOpen ? (
                  <div ref={dropdownRef}>
                    <div>
                      <Filters
                        handleCloseFilter={() => handleCloseFilter()}
                        handleFilteredData={(filteredData) =>
                          handleFilteredData(filteredData)
                        }
                        parentSelectedOptions={selectedOptions}
                        handleUpdateParentfilterDataList={(filterDataList) =>
                          handleUpdatefilterDataList(filterDataList)
                        }
                        handleSetInitialSelectedOptions={(
                          initialSelectedOption
                        ) =>
                          handleSetInitialSelectedOptions(initialSelectedOption)
                        }
                      />
                    </div>
                  </div>
                ) : (
                  <div></div>
                )}
              </div>
            </div>
            {
              // only show when there filter present
              (() => {
                let tempSelectedOptions = JSON.parse(
                  JSON.stringify(selectedOptions)
                );
                let onlyDataSelectedOptions =
                  removeEmptyArrays(tempSelectedOptions);
                let selectedOptionsArray = Object.keys(onlyDataSelectedOptions);

                if (selectedOptionsArray.length > 0) {
                  return (
                    <div className="d-flex justify-content-between my-3">
                      <div className="d-flex gap-4 overflow-auto w-75 pb-1">
                        {renderFilterCards()}
                      </div>
                      <div
                        onClick={() => handleResetFilter()}
                        className="reset-filters"
                      >
                        Reset Filters
                      </div>
                    </div>
                  );
                }
              })()
            }
          </div>

          <div className="profile-table table-container-sample">
            <table>
              <thead>
                <tr>
                  <th>
                    <div className="filter">
                      <p className="label">Name</p>
                      {/* {!checkIsSubEmpOpen(JSON.parse(JSON.stringify(myTeamData))) && (
                                            handleSortDomCreateion('employeeName')
                                        )} */}
                    </div>
                  </th>
                  <th style={{ width: 250 }}>
                    <div className="filter">
                      <p className="label">Email</p>
                      {/* {!checkIsSubEmpOpen(JSON.parse(JSON.stringify(myTeamData))) && (

                                            handleSortDomCreateion('employeeGrade')
                                        )} */}
                    </div>
                  </th>
                  <th>
                    <div className="filter">
                      <p className="label">Approved</p>
                    </div>
                  </th>
                  <th>
                    <div className="filter">
                      <p className="label">Pending approval</p>
                    </div>
                  </th>
                  <th>
                    <div className="filter">
                      <p className="label">Feedback received</p>
                    </div>
                  </th>
                  <th
                    className="  text-center"
                    colSpan={2}
                    style={{ width: 300 }}
                    align="center"
                  >
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {myTeamData?.data?.map((val, index) => (
                  <tr key={index} style={{ cursor: "pointer" }}>
                    <td className="sticky">
                      <div
                        className="details"
                        style={{
                          marginLeft: Number(val?.level ? val.level : 0) * 17,
                          paddingLeft: Number(val?.level ? 1 : 0) * 15,
                          borderLeft: val?.level ? "1px solid #e3e3e3" : "",
                        }}
                      >
                        {/* {val?.isManager && !val?.isOpened ?
                                                        (((subEmployeeLoadId == val?.employeeId) && (isSubEmployeeLoading)) ? <CircularProgress style={{width: '25px', height: '25px'}} /> : <img style={{opacity: isSubEmployeeLoading ? '30%' : '100%', pointerEvents: isSubEmployeeLoading ? 'none' : 'auto'}} src={plus} alt="plus" onClick={() => getEmployeesPlus(val?.employeeId, val?.company, val?.level ? val.level : 0, index + 1)} />)
                                                        : val?.isManager && val?.isOpened ?
                                                            <img style={{cursor: checkIsParentSubEmpOpen(val?.employeeId, index, JSON.parse(JSON.stringify(myTeamData))) ? 'none' : 'pointer', pointerEvents: checkIsParentSubEmpOpen(val?.employeeId, index, JSON.parse(JSON.stringify(myTeamData))) ? 'none' : 'auto', opacity: checkIsParentSubEmpOpen(val?.employeeId, index, JSON.parse(JSON.stringify(myTeamData))) ? '0.3' : '1'}} src={minusClose} alt="minus" onClick={() => getEmployeeMinus(val?.employeeId,index+1)} />
                                                            : <img src={plus} alt="plus" className="hidden" />} */}

                        {val?.profilePhotoPath ? (
                          <img
                            src={val.profilePhotoPath}
                            className="userImage"
                            alt="User Profile"
                            onClick={() =>
                              clickEmp(val?.employeeId, val?.company)
                            }
                          />
                        ) : (
                          <Avatar
                            name={val?.employeeName || "Unknown User"}
                            size="40"
                            round={true}
                            onClick={() =>
                              clickEmp(val?.employeeId, val?.company)
                            }
                          />
                        )}
                        <div
                          className="detailsInner"
                          onClick={() =>
                            clickEmp(val?.employeeId, val?.employeeName)
                          }
                        >
                          <p className="title">{val?.name}</p>
                          {/* <p className="empId">Emp id: {val?.employeeId}</p> */}
                          <p className="empDesignation">{val?.employeeDesignation}</p>
                        </div>
                      </div>
                    </td>
                    <td>{val?.email}</td>
                    <td>{val?.approvedRequestCount}</td>
                    <td>{val?.pendingForApprovalRequestCount}</td>
                    <td>{val?.feedbackRecievedRequestCount}/{val?.totalRequestCount}</td>
                    <td className="table-action-button">View nominations</td>
                    <td className="table-action-button">Download</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {/* {
                        isEmptyNullUndefined(myTeamData?.data) && (

                            <Stack width={'fullWidth'} justifyContent={'center'} display={'flex'} textAlign={'center'}>
                                No data found...!
                            </Stack>
                        )
                    } */}
          </div>
          {/* <div style={{ display: "flex", justifyContent: "center", padding: "1rem" }}>
                        {
                            !myTeamLoader && <Pagination count={myTeamData?.totalPages} page={page} onChange={handleChange} />
                        }
                    </div> */}
        </div>
      </div>
    </div>
  );
};

export default ApproveNominations;
