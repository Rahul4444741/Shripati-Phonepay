import React from 'react';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Chip, Avatar
} from '@mui/material';
import { blue, orange, red, grey } from '@mui/material/colors';

const getStatusChip = (status) => {
  switch (status) {
    case 'Approved':
      return <Chip label="Approved" style={{ backgroundColor: blue[50], color: blue[500] }} />;
    case 'Approval Pending':
      return <Chip label="Approval Pending" style={{ backgroundColor: orange[50], color: orange[500] }} />;
    case 'Denied':
      return <Chip label="Denied" style={{ backgroundColor: red[50], color: red[500] }} />;
    case 'Recalled':
      return <Chip label="Recalled" style={{ backgroundColor: grey[50], color: grey[500] }} />;
    default:
      return <Chip label={status} />;
  }
};

const EmployeeTable = ({ data }) => {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead style={{background: '#F9FAFB'}}>
          <TableRow>
            <TableCell className='table-header-style table-name-sticky-coll-header' style={{ textAlign: 'center' }}>Name</TableCell>
            <TableCell className='table-header-style' style={{ textAlign: 'center' }}>Email Id</TableCell>
            <TableCell className='table-header-style' style={{ textAlign: 'center' }}>Criticality</TableCell>
            <TableCell className='table-header-style' style={{ textAlign: 'center' }}>Status</TableCell>
            {/* <TableCell>Action</TableCell> */}
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((row, index) => (
            <TableRow key={index}>
              <TableCell className='table-name-sticky-coll-body'>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <Avatar src={row.avatar} alt={row.name} />
                  <div style={{ marginLeft: '10px' }}>
                    <div className='table-employee-name'>{row.name}</div>
                    <div className='table-employee-designation'>{row.role}</div>
                  </div>
                </div>
              </TableCell>
              <TableCell style={{ textAlign: 'center' }}>{row.email}</TableCell>
              <TableCell style={{ textAlign: 'center' }}>{row.criticality}</TableCell>
              <TableCell style={{ textAlign: 'center' }}>{getStatusChip(row.nominationStatus)}</TableCell>
              {/* <TableCell>
                <button style={{ background: 'none', border: 'none', cursor: 'pointer' }}>⋮</button>
              </TableCell> */}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default EmployeeTable;
