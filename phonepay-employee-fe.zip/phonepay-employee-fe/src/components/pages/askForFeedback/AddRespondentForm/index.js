import {
  FormControl,
  FormHelperText,
  ListItemText,
  MenuItem,
  Select,
  Autocomplete,
  Avatar,
  CircularProgress,
  InputAdornment,
  InputLabel,
  TextField,
} from "@mui/material";
import JoditEditor from "jodit-react";
import React, { useMemo, useRef, useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { isEmptyNullUndefined, options } from "../../../utils/utils";
import "suneditor/dist/css/suneditor.min.css";
import { RiErrorWarningFill } from "react-icons/ri";
import SunEditor from "suneditor-react";
import APIList from "../../../../api";
// import searchIcon from "../../../assets/images/searchIcon.svg"
import searchIcon from "../../../../assets/images/searchIcon.svg";
import { toast } from "react-toastify";
import debounce from "lodash.debounce";

//////////// import for search/// start////////
import { Skeleton } from "@mui/material";
import {
  Search,
  SearchIconWrapper,
  StyledInputBase,
} from "../../../utils/utils";
import { IoMdSearch } from "react-icons/io";
import { IoCloseSharp } from "react-icons/io5";
import { BsFillCheckCircleFill } from "react-icons/bs";
//////////////////////////end/////////////////

const AddRespondentForm = ({ setIsOpen }) => {
  const history = useHistory();
  const employeeDetails = useSelector((state) => state?.empData?.empData);
  const [respondent, setRespondent] = useState(null);
  const [criticality, setCriticality] = useState("Critical");
  const [submitLoader, setSubmitLoader] = useState(false);

  //////////////////// search state start /////////////
  const [currentPage, setCurrentPage] = useState(0);
  const [search, setSearch] = useState("");
  const [searchLoader, setSearchLoader] = useState(false);
  const [filterPayload, setFilterPayload] = useState({});
  const [firstLoad, setFirstLoad] = useState(true);
  const [totalSearchPages, setTotalSearchPages] = useState(0);
  const [searchedList, setsearchedList] = useState(null);
  const [isSearch, setIsSearch] = useState(false);
  const [showAllSearches, setShowAllSearches] = useState(false);
  //////////////////search state end////////////////////

  

  let defaultMsg = `<p>
  <p>Dear User,</p>

  <p> I hope this message finds you well.</p>

  <p> As part of my performance appraisal process, I would greatly appreciate your valuable feedback.
   Your insights are crucial to my professional growth. Please take a moment to share your thoughts. Thank you for your time. </p>

   Best regards,
   <p>${employeeDetails?.name}</p>
  </p>`;
  const [message, setMessage] = useState(defaultMsg);

  const [formData, setFormData] = useState({
    respondent: null,
    criticality: null,
    message: defaultMsg,
  });
  const [formDataError, setFormDataError] = useState({
    respondent: { isError: false, errorMessage: "" },
    criticality: { isError: false, errorMessage: "" },
    message: { isError: false, errorMessage: "" },
  });

  //////////////old search start///////////////
  const [dropdownOptions, setDropdownOptions] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [searchLoading, setSearchLoading] = useState(false);
    //////////////old search end///////////////

  const editor = useRef(null);

  const config = useMemo(
    () => ({
      readonly: false,
      placeholder: `Provide your feedback here...`,
      // defaultActionOnPaste: "insert_as_html",
      defaultActionOnPaste: "insert_only_text",
      askBeforePasteFromWord: false,
      askBeforePasteHTML: false,
      defaultLineHeight: 1.5,
      enter: "div",
      // options that we defined in above step.
      buttons: options,
      buttonsMD: options,
      buttonsSM: options,
      buttonsXS: options,
      statusbar: false,
      sizeLG: 900,
      sizeMD: 700,
      sizeSM: 400,
      showCharsCounter: true, // Show character count in the footer
      showWordsCounter: true, // Show word count in the footer (optional)
      showLinesCounter: true, // Show line count (optional)
      statusbar: true, // Enable the status bar
      toolbarAdaptive: false,
    }),
    []
  );

  const fetchEmployees = debounce((keyword) => {
    setSearchLoading(true);
    APIList.searchMyTeam({
      payload: {
        keyword,
        companyId: employeeDetails?.company?.id,
      },
    })
      .then((res) => {
        setDropdownOptions(res?.data?.data || []);
        setSearchLoading(false);
        if (res.data.data.length === 0) {
          toast.error(
            <div style={{ display: "flex", alignItems: "center" }}>
              <RiErrorWarningFill style={{ width: "2rem", height: "2rem" }} />
              &nbsp;&nbsp;No record found...!
            </div>
          );
        }
      })
      .catch((err) => {
        toast.error(
          <div style={{ display: "flex", alignItems: "center" }}>
            <RiErrorWarningFill style={{ width: "2rem", height: "2rem" }} />
            &nbsp;&nbsp;{err?.title || "An error occurred"}
          </div>
        );
        setSearchLoading(false);
      });
  }, 300);

  const handleInputChange = (event, newInputValue) => {
    setInputValue(newInputValue);
    fetchEmployees(newInputValue);
  };

  const handleSelectionChange = (event, newValue) => {
    setSelectedEmployee(newValue);
  };

  ///////////////////////// search fun//////////
  function HandleOutsideClick(ref) {
    useEffect(() => {
      function handleClickOutside(event) {
        if (ref.current && !ref.current.contains(event.target)) {
          setIsSearch(false);
          setSearch("");
        }
      }
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }, [ref]);
  }
  const wrapperRef = useRef(null);
  HandleOutsideClick(wrapperRef);
  useEffect(() => {
    const getSearch = setTimeout(() => {
      setSearchLoader(true);

      if (!isEmptyNullUndefined(search)) {
        setIsSearch(true);
        if (!firstLoad) {
          APIList.getFilteredSearchPeersfeed({
            payload: {
              employeeEligibilityDTO: filterPayload,
              keyword: search,
              employeeId: employeeDetails?.id,
              managerId: employeeDetails?.manager?.id,
              companyId: employeeDetails?.company?.id,
              page: "peer-feedback",
            },
            page: currentPage,
            size: showAllSearches ? 10000 : 3,
          })
            .then((res) => {
              setsearchedList(res?.data?.data);
              setTotalSearchPages(res?.data?.totalPages);
              setSearchLoader(false);
            })
            .catch((err) => {
              setSearchLoader(false);
            });
        }
      }
    }, 500);

    return () => clearTimeout(getSearch);
  }, [search, showAllSearches]);

  useEffect(() => {
    setFirstLoad(false);
  }, [currentPage]);

  const autoSearchText = (e) => {
    setCurrentPage(0);
    setShowAllSearches(false);
    setSearch(e.target.value);
  };
  ///////////////////////search fun end///////////////////////

  const handleChange = (event, fieldType) => {
    const tempFormData = { ...formData };
    const tempFormDataError = { ...formDataError };

    if (fieldType == "TextField" || fieldType == "dropdown") {
      tempFormData[event.target.name] = event.target.value;
      tempFormDataError[event.target.name].isError = false;
      tempFormDataError[event.target.name].errorMessage = "";
    }
    if (fieldType == "autocomplete") {
      console.log("event", event);
      tempFormData.respondent = event;
      tempFormDataError.respondent.isError = false;
      tempFormDataError.respondent.errorMessage = "";

      /// set message ///
      tempFormData.message = `<p>
      <p>Dear ${tempFormData.respondent.employeeName},</p>

      <p> I hope this message finds you well.</p>

      <p> As part of my performance appraisal process, I would greatly appreciate your valuable feedback.
      Your insights are crucial to my professional growth. Please take a moment to share your thoughts. Thank you for your time. </p>

      Best regards,
      <p>${employeeDetails?.name}</p>
      </p>`;

    }
    if (fieldType == "editor") {
      tempFormData.message = event;
      tempFormDataError.message.isError = false;
      tempFormDataError.message.errorMessage = "";
    }

    setFormData(() => tempFormData);
    setFormDataError(() => tempFormDataError);
  };

  const validateData = () => {
    const tempFormDataError = { ...formDataError };
    let isValid = true;
    if (isEmptyNullUndefined(formData.respondent)) {
      tempFormDataError.respondent.isError = true;
      tempFormDataError.respondent.errorMessage = "Please select respondent.";
      isValid = false;
    }
    if (isEmptyNullUndefined(formData.criticality)) {
      tempFormDataError.criticality.isError = true;
      tempFormDataError.criticality.errorMessage = "Please select criticality.";
      isValid = false;
    }
    if (isValid) {
      console.log('true is validate')
      submitRequest();
    } else {
      console.log('false is validate')
      setFormDataError(() => tempFormDataError);
    }
  };

  const submitRequest = () => {    
    setSubmitLoader(true);
    APIList.sendFeedbackRequest({
      // APIList.po({
        requestedBy:{ 
            id: employeeDetails?.id
        },
        requestedTo:{
            // id: peer?.employeeId
            id: formData.respondent.employeeId //660cc1e7-d3e5-4156-84e6-65363c5e62c7
        },
        relationship: "Peer",
        message: message,
        // expiryDate: dateExpected,

        isResend: false,
        managerInitiatesPeerFeedback :false,
        initiateManager :null,

        // isCritical: ((isCritical === true) || (isCritical === 'true')) ? true : false,
        isCritical: (formData.criticality === 'CRITICAL') ? true : false,
        
        // feedbackFormId,
        feedbackFormId: null // option peerfeedbackform selection

    })  
    .then((res) => {
        toast.success(
            <div className="flex flex-row">
              <BsFillCheckCircleFill
                style={{ width: "2rem", height: "2rem" }}
              />
              {` Request sent successfully`}
            </div>
          );
          setSubmitLoader(false);
          setIsOpen(false);
          setSearch("");
    })
    .catch((err) => {
        toast.error(
            <div style={{display:"flex", flexDirection:"row"}}>
              <RiErrorWarningFill style={{ width: '2rem', height: '2rem' }} />
              &nbsp;&nbsp;{err?.message}
            </div>
        );
        setSubmitLoader(false);
        setSearch("");
    })               
  }

  return (
    <div className="add-respondent-form">
      <div className="header-title">Add A Respondent</div>
      <div className="header-desc">(Nomination Closure on 20/10/2024)</div>

      <div>
        <div className="form-group">
          <div className="fields-container">
            <div style={{ display: "flex", flexDirection: "column" }}>
              <p style={{marginBottom: '17px'}} className="question">
                Respondent<span style={{ color: "red" }}>*</span>
              </p>
              <div className="right-container-search">
                {/* <Autocomplete
                  id="searchemp"
                  disableClearable
                  options={dropdownOptions || []}
                  // value={selectedEmployee}
                  value={formData?.respondent}
                  name="respondent"
                  onChange={(event, newValue) =>
                    handleChange(newValue, "autocomplete")
                  }
                  onInputChange={handleInputChange}
                  fullWidth
                  freeSolo
                  disableCloseOnSelect
                  getOptionLabel={(option) => option?.employeeName || ""}
                  isOptionEqualToValue={(option, value) =>
                    option.employeeId === value.employeeId
                  }
                  renderOption={(props, option) => (
                    <li
                      {...props}
                      style={{
                        display: "flex",
                        padding: 10,
                        borderBottom: "0.6px solid #F3F3F3",
                        width: "300px",
                      }}
                    >
                      <div
                        className="searchOptions"
                        style={{ display: "flex" }}
                      >
                        <div style={{ margin: "0rem 1.2rem" }}>
                          {option?.employeeName}
                        </div>
                      </div>
                    </li>
                  )}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      placeholder="Search using name..."
                      fullWidth
                      variant="outlined"
                      style={{
                        width: "100%",
                        margin: "0",
                        padding: "0",
                        height: "2.8rem",
                        float: "right",
                        maxWidth: "300px",
                      }}
                      InputProps={{
                        ...params.InputProps,
                        style: {
                          height: "2.8rem",
                          padding: "0 8px",
                          lineHeight: "25px",
                        },
                        endAdornment: (
                          <InputAdornment position="end">
                            {searchLoading ? (
                              <div className="d-flex">
                                <CircularProgress
                                  style={{ width: "20px", height: "20px" }}
                                />
                              </div>
                            ) : (
                              <img
                                src={searchIcon}
                                className="searchIcon"
                                alt="Search Icon"
                              />
                            )}
                          </InputAdornment>
                        ),
                      }}
                    />
                  )}
                /> */}

                                   
                                      <div className="search-wrapper">
                                        <div className="second-div">
                                          <Search 
                                            // style={{margin: '0 !important'}}  
                                            ref={wrapperRef}
                                          >
                                            <SearchIconWrapper>
                                              <IoMdSearch />
                                            </SearchIconWrapper>
                                            <StyledInputBase
                                              // placeholder="Search by username or email"
                                              placeholder={formData?.respondent?.employeeName ? formData.respondent.employeeName : "Search by username or email"}
                                              inputProps={{ "aria-label": "search" }}
                                              onChange={autoSearchText}
                                              value={search}
                                              // style={{border: '1px solid #D0D5DD',borderRadius: '4px'}}
                                            />
                                            {!isEmptyNullUndefined(search) && (
                                              <IoCloseSharp
                                                onClick={() => {
                                                  setSearch("");
                                                  setShowAllSearches(false);
                                                }}
                                                style={{
                                                  position: "absolute",
                                                  right: "10px",
                                                  top: "34%",
                                                  color: "gray",
                                                  cursor: "pointer",
                                                }}
                                              />
                                            )}

                                            {!isEmptyNullUndefined(search) && isSearch && (
                                              <div className="search-popup-req-feed">
                                                {searchLoader ? (
                                                  <>
                                                    <div className="search-emp-outer">
                                                      <div className="empDetaila">
                                                        <div className="empPic">
                                                          <Skeleton variant="circular" width={40} height={40} />
                                                        </div>
                                                        <div className="userInfo">
                                                          <p className="name">
                                                            <Skeleton
                                                              variant="text"
                                                              sx={{ fontSize: "1rem", width: "7rem" }}
                                                            />
                                                          </p>
                                                          <p className="designation">
                                                            <Skeleton
                                                              variant="text"
                                                              sx={{ fontSize: "0.5rem", width: "3rem" }}
                                                            />
                                                          </p>
                                                        </div>
                                                      </div>
                                                      <p className="name">
                                                        <Skeleton
                                                          variant="text"
                                                          sx={{ fontSize: "1.5rem", width: "2rem" }}
                                                        />
                                                      </p>
                                                    </div>
                                                    <div className="search-emp-outer">
                                                      <div className="empDetaila">
                                                        <div className="empPic">
                                                          <Skeleton variant="circular" width={40} height={40} />
                                                        </div>
                                                        <div className="userInfo">
                                                          <p className="name">
                                                            <Skeleton
                                                              variant="text"
                                                              sx={{ fontSize: "1rem", width: "7rem" }}
                                                            />
                                                          </p>
                                                          <p className="designation">
                                                            <Skeleton
                                                              variant="text"
                                                              sx={{ fontSize: "0.5rem", width: "3rem" }}
                                                            />
                                                          </p>
                                                        </div>
                                                      </div>
                                                      <p className="name">
                                                        <Skeleton
                                                          variant="text"
                                                          sx={{ fontSize: "1.5rem", width: "2rem" }}
                                                        />
                                                      </p>
                                                    </div>
                                                  </>
                                                ) : searchedList?.length > 0 ? (
                                                  <div>
                                                    {searchedList?.map((emp, index) => {
                                                      return (
                                                        <div key={index} className="search-emp-outer">
                                                          
                                                          <div onClick={() => setSearch(() => handleChange(emp, "autocomplete"))}  className="empDetaila">
                                                            <div className="empPic">
                                                              {emp?.profilePhotoPath ? (
                                                                <img
                                                                  src={emp?.profilePhotoPath}
                                                                  className="userImg"
                                                                  alt="User Image"
                                                                />
                                                              ) : (
                                                                <Avatar
                                                                  name={emp?.employeeName}
                                                                  size="40"
                                                                  className="userImg"
                                                                  color={"#00425A"}
                                                                />
                                                              )}
                                                            </div>
                                                            <div className="userInfo">
                                                              <p className="name">{emp?.employeeName}</p>
                                                              <p className="designation">
                                                                {emp?.employeeDesignation ?? ""}
                                                              </p>
                                                              <p
                                                                style={{
                                                                  width: "150px",
                                                                  overflow: "hidden",
                                                                }}
                                                                className="designation"
                                                              >
                                                                {emp?.emailId}
                                                              </p>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      );
                                                    })}
                                                    {!showAllSearches && totalSearchPages > 1 && (
                                                      <div
                                                        className="view-all-search"
                                                        onClick={() => setShowAllSearches(true)}
                                                      >
                                                        View all
                                                      </div>
                                                    )}
                                                  </div>
                                                ) : (
                                                  <div className="no-result">No result</div>
                                                )}
                                              </div>
                                            )}
                                          </Search>
                                        </div>
                                      </div>
                                    
              </div>
              {formDataError.respondent.isError && (
                <FormHelperText className="Mui-error">
                  {formDataError.respondent.errorMessage}
                </FormHelperText>
              )}
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                width: "300px",
              }}
            >
              <p className="question">
                Is this stakeholder's feedback critical to you?
                <span style={{ color: "red" }}>*</span>
              </p>
              <FormControl>
                <Select
                  name="criticality"
                  labelId="criticality"
                  id="demo-simple-select"
                  value={formData.criticality || ""}
                  onChange={(event) => handleChange(event, "dropdown")}
                  size="small"
                >
                  <MenuItem key={"CRITICAL"} value={"CRITICAL"}>
                    <ListItemText primary={"Critical"} />
                  </MenuItem>
                  <MenuItem key={"NOT_CRITICAL"} value={"NOT_CRITICAL"}>
                    <ListItemText primary={"Not Critical"} />
                  </MenuItem>
                </Select>
              </FormControl>
              {formDataError.criticality.isError && (
                  <FormHelperText className="Mui-error">
                    {formDataError.criticality.errorMessage}
                  </FormHelperText>
                )}
            </div>
          </div>
        </div>
        <div className="form-group"></div>
        <div className="form-group">
          <p className="question">Any message for them?</p>
          <div
            style={{
              marginTop: "1rem",
            }}
          >
            <JoditEditor
              ref={editor}
              config={config}
              name="message"
              value={formData.message}
              // onChange={(event) => handleChange(event, "editor")}
              onBlur={(event) => handleChange(event, "editor")}
            />
          </div>
        </div>
        <div className="form-actions">
          <button
            type="button"
            className="cancel-button"
            onClick={() => setIsOpen(false)}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="button send-button"
            onClick={validateData}
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddRespondentForm;
