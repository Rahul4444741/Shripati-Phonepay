import ThreeSixtyHeaderIcon from "../../../assets/images/dynamicSidebar/threeSixtyHeaderIcon";

const HeaderWellcomeCard = () => {
  return (
      <div className="main-card">
        <div
          className="text"
          style={{
            alignContent: "center",
          }}
        >
          <div
            className="header"
            style={{
              fontWeight: "600",
              fontSize: "24px",
              color: "white",
              marginBottom: "8px",
            }}
          >
            Welcome to Mid Year 2023-24: 360 Feedback Process
          </div>
          <div className="paragraph">
            <div
              style={{
                fontWeight: "400",
                fontSize: "14",
                color: "#D6BBFB",
              }}
            >
              1. Nomination - Click on Ask for feedback to nominate stakeholders
              for 360 feedback. Once you’re done nominating stakeholders, click
              on send approval request.
            </div>
            <div
              style={{
                fontWeight: "400",
                fontSize: "14",
                color: "#D6BBFB",
              }}
            >
              2. Evaluation - Under Give feedback to others, click on the
              relevant employee name to fill their 360 feedback form.
            </div>
          </div>
        </div>
        <div className="icon">
          <ThreeSixtyHeaderIcon />
        </div>
      </div>

  );
};

export default HeaderWellcomeCard;
