// rowOne: {'Approved': 3},
// rowOne: {'Approval Pending': 6},
// rowOne: {'Rejected By Manager': 9},

import { isEmptyNullUndefined } from "../../utils/utils"

const NominationsCard = ({data}) => {
  console.log('data', data)
  console.log(Object.keys(data.rowOne)) 
  console.log('data', data['Approved'])

  return (
    <div className="nominations-card">
      <h4>Nominations: Added by Employee</h4>
      <div className="divider"></div>
      {(!isEmptyNullUndefined(data?.rowOne)) && <div className="container">
        <div className="title">
            {Object.keys(data.rowOne)[0]}
        </div>
        <div className="value">
          {data.rowOne[Object.keys(data.rowOne)[0]]}
        </div>
      </div>}
      {(!isEmptyNullUndefined(data?.rowTwo)) && <div className="container">
        <div className="title">
          {Object.keys(data.rowTwo)[0]}
        </div>
        <div className="value">
          {data.rowTwo[Object.keys(data.rowTwo)[0]]}
        </div>
      </div>}
      {(!isEmptyNullUndefined(data?.rowThree)) && <div className="container">
        <div className="title">
          {Object.keys(data.rowThree)[0]}
        </div>
        <div className="value">
          {data.rowThree[Object.keys(data.rowThree)[0]]}
        </div>
      </div>}
    </div>
  );
};

export default NominationsCard;
